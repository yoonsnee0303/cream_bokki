with open('cou_list.txt', 'r', newline='', encoding='utf-8-sig') as f:
    read = f.read()

print(read)

read = read.split('\n')
mylist = list(dict.fromkeys(read))
print(mylist)
print(len(mylist))